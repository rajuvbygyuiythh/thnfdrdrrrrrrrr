#!/usr/bin/env python3
"""
register_browser.py - Fully automatic Thundr account registration via Playwright.

Standalone - it only appends accounts to registered_accounts.txt / registered_creds.txt
and does not modify chat.py or settings.txt.

Flow (per account):
  1. Open https://thundr.com/create
  2. Fill username / password / confirm
  3. Click "Create Account"  -> POST /api/register -> redirect to /register
  4. Complete /register onboarding (age gate, birthday, sex, looking for)
  5. Click "Finish Registration" -> POST https://id.thundr.com/api/users
  6. Extract user_id / email / hashed_token from localStorage["user"]
  6. Append "user_id|email|hashed_token" to registered_accounts.txt

Outputs:
  registered_accounts.txt  - user_id|email|hashed_token (one per line)
  registered_creds.txt     - username|password|user_id|hashed_token (your records)
  registration_trace.jsonl - API request/response trace

Usage:
  python register_browser.py                  # register 1 account (headed)
  python register_browser.py --count 5        # register 5 accounts
  python register_browser.py --headless       # no visible browser
  python register_browser.py --start          # then launch chat.py with acct:... on the CLI
  python register_browser.py --keep-open      # leave the browser open after registering
"""
import asyncio
import json
import random
import string
import sys
import subprocess
from datetime import datetime
from pathlib import Path

try:
    from playwright.async_api import async_playwright
except ImportError:
    async_playwright = None

BASE_DIR = Path(__file__).parent
TRACE_FILE = BASE_DIR / "registration_trace.jsonl"
ACCOUNTS_FILE = BASE_DIR / "registered_accounts.txt"
CREDS_FILE = BASE_DIR / "registered_creds.txt"

INTEREST = ("/api/register", "/api/users", "/login")


def gen_username():
    return "thr_" + "".join(random.choices(string.ascii_lowercase + string.digits, k=8))


def gen_password():
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*"
    return "".join(random.choices(alphabet, k=12))


def trace(entry):
    with open(TRACE_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


async def wait_ready(page, timeout=15000):
    try:
        await page.wait_for_load_state("networkidle", timeout=timeout)
    except Exception:
        pass


async def _click_text(page, text, label):
    try:
        btn = page.locator(f'button:has-text("{text}")')
        if await btn.count() > 0:
            await btn.first.click(timeout=5000)
            await page.wait_for_timeout(900)
            print(f"   - {label}")
            return True
    except Exception as e:
        print(f"   - {label} failed: {e}")
    return False


async def _click_aria(page, aria_label, label):
    try:
        btn = page.locator(f'button[aria-label="{aria_label}"]')
        if await btn.count() > 0:
            await btn.first.click(timeout=5000)
            await page.wait_for_timeout(900)
            print(f"   - {label}")
            return True
    except Exception as e:
        print(f"   - {label} failed: {e}")
    return False


async def _select_option(page, option_label, label):
    try:
        sel = page.locator("select").filter(has_text=option_label)
        if await sel.count() > 0:
            await sel.first.select_option(label=option_label, timeout=5000)
            await page.wait_for_timeout(500)
            print(f"   - {label}")
            return True
    except Exception as e:
        print(f"   - {label} failed: {e}")
    return False


async def register_one(page, index, total):
    """Register a single account on an already-open page. Returns dict or None."""
    username = gen_username()
    password = gen_password()

    print("\n" + "=" * 60)
    print(f"  [{index}/{total}] Registering: {username}")
    print("=" * 60)

    # ---- 1. /create ----
    print("1. Opening https://thundr.com/create ...")
    await page.goto("https://thundr.com/create", wait_until="domcontentloaded")
    await wait_ready(page)

    print("2. Filling username / password ...")
    try:
        await page.fill('input[placeholder="Choose a unique username"]', username, timeout=15000)
        await page.fill('input[placeholder="Choose a password"]', password, timeout=15000)
        await page.fill('input[placeholder="Confirm your password"]', password, timeout=15000)
    except Exception as e:
        print(f"   Could not fill form: {e}")
        await page.screenshot(path=str(BASE_DIR / "reg_debug_create.png"))
        return None

    print("3. Clicking 'Create Account' ...")
    await page.click('button[aria-label="Create Account"]')

    print("   Waiting for /api/register response ...")
    try:
        await page.wait_for_url("**/register**", timeout=25000)
        print("   -> redirected to /register")
    except Exception:
        print("   !! no redirect to /register within 25s")
        errs = await page.evaluate(
            "() => [...document.querySelectorAll('p')].map(e => e.textContent).filter(t => t && t.trim())"
        )
        print(f"   page text: {errs[:5]}")
        await page.screenshot(path=str(BASE_DIR / "reg_debug_after_create.png"))
        return None

    await wait_ready(page)

    # ---- 2. /register onboarding ----
    print("4. Completing /register onboarding ...")
    try:
        agree = page.locator('button:has-text("I Agree")')
        if await agree.count() > 0:
            await agree.first.click()
            await page.wait_for_timeout(1000)
            print("   - Age gate: I Agree")
    except Exception:
        pass

    try:
        sels = page.locator("select")
        if await sels.count() >= 3:
            await sels.nth(0).select_option(label="January", timeout=5000)
            await sels.nth(1).select_option(label="15", timeout=5000)
            await sels.nth(2).select_option(label="1990", timeout=5000)
            print("   - Birthday: January 15, 1990")
    except Exception as e:
        print(f"   - Birthday: {e}")

    await _click_text(page, "Next", "Next (-> sex)")
    await _select_option(page, "Male", "Sex: Male")
    await _click_text(page, "Next", "Next (-> looking for)")
    await _select_option(page, "Everyone", "Looking for: Everyone")
    await _click_aria(page, "Finish Registration", "Finish Registration")

    # ---- 3. wait for /api/users + localStorage ----
    print("   Waiting for /api/users + localStorage ...")
    user = {}
    for _ in range(30):
        await page.wait_for_timeout(500)
        user = await page.evaluate("() => JSON.parse(localStorage.getItem('user') || '{}')")
        if user.get("hashed_token"):
            break

    # Try to click "Start Chatting" if it appears (final onboarding CTA)
    try:
        start_btn = page.locator('button[aria-label="Start Chatting"]')
        if await start_btn.count() > 0:
            await start_btn.first.click(timeout=3000)
            await page.wait_for_timeout(800)
            print("   - Start Chatting")
    except Exception as e:
        print(f"   - Start Chatting skipped: {e}")

    user_id = user.get("id")
    email = user.get("email")
    hashed_token = user.get("hashed_token")

    print("5. Extracted:")
    print(f"   user_id      : {user_id}")
    print(f"   email        : {email}")
    print(f"   hashed_token : {hashed_token}")

    if not (user_id and email and hashed_token):
        print("   !! incomplete - see registration_trace.jsonl")
        return None

    # save locally
    with open(ACCOUNTS_FILE, "a", encoding="utf-8") as f:
        f.write(f"{user_id}|{email}|{hashed_token}\n")
    with open(CREDS_FILE, "a", encoding="utf-8") as f:
        f.write(f"{username}|{password}|{user_id}|{hashed_token}\n")

    return {
        "username": username,
        "password": password,
        "user_id": user_id,
        "email": email,
        "hashed_token": hashed_token,
    }


def start_chat(accounts):
    """Launch one chat.py process carrying every registered account on the CLI."""
    if not accounts:
        return
    try:
        venv_py = Path(r"C:\Users\aminee\Desktop\PythonProject\.venv\Scripts\python.exe")
        py = str(venv_py) if venv_py.exists() else sys.executable
        cmd = [py, str(BASE_DIR / "chat.py")]
        for a in accounts:
            cmd.append(f"acct:{a['user_id']}|{a['email']}|{a['hashed_token']}")
        # its own console window: survives run.bat closing, and shows live logs
        flags = subprocess.CREATE_NEW_CONSOLE if sys.platform == "win32" else 0
        subprocess.Popen(cmd, cwd=str(BASE_DIR), creationflags=flags)
        print(f"  Started chat.py with {len(accounts)} account(s) via CLI (no API)")
        for a in accounts:
            print(f"    - {a['user_id']}|{a['email']}|{a['hashed_token']}")
    except Exception as e:
        print(f"  Failed to start chat.py: {e}")


async def run(count, headless):
    if async_playwright is None:
        print("Playwright not installed: pip install playwright && playwright install chromium")
        return []

    if TRACE_FILE.exists():
        TRACE_FILE.unlink()

    keep_open = "--keep-open" in sys.argv
    results = []
    page = None
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=headless)
        for i in range(1, count + 1):
            ctx = await browser.new_context()  # fresh localStorage per account
            page = await ctx.new_page()

            def make_handlers(pg):
                def on_response(res):
                    if any(h in res.url for h in INTEREST):
                        async def _grab():
                            try:
                                body = (await res.body()).decode("utf-8", "replace")[:4000]
                            except Exception:
                                body = "<unreadable>"
                            trace({"ts": datetime.now().isoformat(), "url": res.url,
                                   "status": res.status, "body": body})
                            print(f"  [API] {res.status} {res.url}")
                            print(f"        {body[:400]}")
                        asyncio.create_task(_grab())
                def on_request(req):
                    if any(h in req.url for h in INTEREST):
                        trace({"ts": datetime.now().isoformat(), "type": "request",
                               "method": req.method, "url": req.url, "post_data": req.post_data})
                        print(f"  [REQ] {req.method} {req.url}")
                        if req.post_data:
                            print(f"        {req.post_data[:400]}")
                pg.on("response", on_response)
                pg.on("request", on_request)

            make_handlers(page)

            try:
                res = await register_one(page, i, count)
            except Exception as e:
                print(f"   registration error: {e}")
                res = None
            finally:
                # --keep-open keeps each registration session alive on screen
                if not keep_open:
                    await ctx.close()

            if res:
                results.append(res)

        # one CLI launch carrying every account registered in this run
        if "--start" in sys.argv:
            start_chat(results)

        if keep_open and page is not None:
            print("Browser left open (--keep-open)")
            try:
                await page.wait_for_timeout(600000)
            except Exception:
                pass

        await browser.close()

    return results


def main():
    count = 1
    if "--count" in sys.argv:
        try:
            count = int(sys.argv[sys.argv.index("--count") + 1])
        except Exception:
            count = 1
    headless = "--headless" in sys.argv

    results = asyncio.run(run(count, headless))

    print("\n" + "=" * 60)
    print(f"  Registered {len(results)}/{count} account(s)")
    print("=" * 60)
    for r in results:
        print(f"  {r['user_id']}|{r['email']}|{r['hashed_token']}")
    if results:
        print(f"\nSaved to: {ACCOUNTS_FILE.name} and {CREDS_FILE.name}")
        print("chat.py will pick them up automatically via the API supervisor.")


if __name__ == "__main__":
    main()
