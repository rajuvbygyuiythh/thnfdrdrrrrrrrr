import json
import random
import subprocess
import sys
import threading
import time
import logging
from datetime import datetime
from pathlib import Path
from urllib.parse import urlencode

from curl_cffi import requests as cffi_requests
from curl_cffi.requests.websockets import WebSocket, WebSocketClosed
from curl_cffi.const import CurlWsFlag

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("chat.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger(__name__)

BASE_DIR = Path(__file__).parent


BAN_KEYWORDS = ("ban", "suspend", "blocked", "kicked")
BAN_CLOSE_CODES = (4003, 4001, 4100)


def load_settings():
    settings = {}
    path = BASE_DIR / "settings.txt"
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and "=" in line and not line.startswith("#"):
                key, val = line.split("=", 1)
                settings[key.strip()] = val.strip()
    return settings


def load_list(filename):
    path = BASE_DIR / filename
    if path.exists():
        return [
            l.strip()
            for l in path.read_text(encoding="utf-8").splitlines()
            if l.strip() and not l.startswith("#")
        ]
    return []


def load_chat_lines():
    path = BASE_DIR / "msg" / "chat.txt"
    if path.exists():
        return [
            l.strip()
            for l in path.read_text(encoding="utf-8").splitlines()
            if l.strip()
        ]
    return []


def replace_templates(text, snaps, telegrams):
    if text is None:
        return None
    if "%snap%" in text and snaps:
        text = text.replace("%snap%", random.choice(snaps))
    if "%tguser%" in text and telegrams:
        text = text.replace("%tguser%", random.choice(telegrams))
    return text



def is_ban_close(code, reason):
    if code in BAN_CLOSE_CODES and code != 1000:
        return True
    reason_lower = str(reason).lower()
    return any(kw in reason_lower for kw in BAN_KEYWORDS)


def load_proxies(filename="proxy5.txt"):
    for name in (filename, "proxies.txt"):
        path = BASE_DIR / name
        if path.exists():
            proxies = []
            for line in path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("http://") or line.startswith("https://") or line.startswith("socks"):
                    proxies.append(line)
                    continue
                parts = line.split(":")
                if len(parts) >= 4:
                    host, port = parts[0], parts[1]
                    user = parts[2]
                    pwd = ":".join(parts[3:])
                    proxies.append(f"http://{user}:{pwd}@{host}:{port}")
                elif len(parts) == 2:
                    proxies.append(f"http://{parts[0]}:{parts[1]}")
            if proxies:
                log.info(f"Loaded {len(proxies)} proxies from {name}")
            return proxies
    return []


def is_ban_payload(payload):
    text = json.dumps(payload).lower()
    return any(kw in text for kw in BAN_KEYWORDS)


def parse_account_line(line):
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    if "|" in line:
        parts = line.split("|")
        if len(parts) >= 3:
            return {"user_id": parts[0].strip(), "email": parts[1].strip(), "hashed_token": parts[2].strip()}
    if ":" in line and line.count(":") >= 2:
        parts = line.split(":")
        return {"user_id": parts[0].strip(), "email": parts[1].strip(), "hashed_token": ":".join(parts[2:]).strip()}
    return None


class ThundrBot:
    def __init__(self, user_id, email, hashed_token, settings, proxy=None, proxy_pool=None):
        self.user_id = user_id
        self.email = email
        self.hashed_token = hashed_token
        self.settings = settings
        self.proxy = proxy
        self.proxy_pool = proxy_pool or []

        self.ws = None
        self.ref = 0
        self.match_topic = f"match:{self.user_id}"
        self.room_topic = None
        self.state = "stopped"
        self.match_id = None

        self.chat_lines = load_chat_lines()
        self.snaps = load_list("snaps.txt")
        self.tg_users = load_list("telegram.txt")
        self.current_line_index = 0

        self.response_time = float(settings.get("stranger_response_time", 3))
        self.wait_time = float(settings.get("stranger_wait_time", 15))
        self.thread_work_time = float(settings.get("thread_work_time", 600))
        self.search_retry_time = float(settings.get("search_retry_time", 10))
        self.started_at = time.time()
        self.last_start_at = 0
        self.reconnect_delay = 0
        self.created_at = str(int(time.time() * 1000))

        self.is_banned = False
        self.banned_user_ids = set()
        self.used_user_ids = set()
        self._stop = False
        self.no_match_retries = 0

    def _update_credentials(self, acc):
        self.user_id = acc["user_id"]
        self.email = acc["email"]
        self.hashed_token = acc["hashed_token"]
        self.match_topic = f"match:{self.user_id}"
        self.room_topic = None
        self.match_id = None
        self.state = "stopped"
        self.is_banned = False
        self.current_line_index = 0
        self.started_at = time.time()
        self.last_start_at = 0
        self.no_match_retries = 0
        self.reconnect_delay = 0
        if self.proxy_pool:
            self.proxy = random.choice(self.proxy_pool)

    def next_ref(self):
        self.ref += 1
        return str(self.ref)

    def build_url(self):
        params = {
            "user_id": self.user_id,
            "email": self.email,
            "hashed_token": self.hashed_token,
            "vsn": "2.0.0",
        }
        return f"wss://api.thundr.com/socket/websocket?{urlencode(params)}"

    def user_payload(self):
        return {
            "user": {
                "created_at": self.created_at,
                "id": self.user_id,
                "email": self.email,
                "onboarded": True,
                "settings": {
                    "device": None,
                    "userDevice": None,
                    "platform": "web",
                    "volume": {"master": 0, "output": 100},
                    "autoRoll": {"video": True, "text": False},
                    "performance": {"lowPower": False, "facePopup": False},
                    "interests": {"wait": 0, "tags": []},
                    "filters": {
                        "countries": [],
                        "regions": [],
                        "sex": [],
                        "max_wait": 3,
                    },
                    "autoMod": True,
                    "mobile": {
                        "swipeSensitivity": 0,
                        "swipeSkip": True,
                        "haptics": True,
                    },
                    "privacy": {"hidden": False},
                    "event": {"looking_for": "a"},
                    "reviewed": None,
                    "notification": None,
                    "profile": {
                        "sex": "m",
                        "looking_for": "m",
                        "dob": "1995-01-01",
                    },
                },
                "verification": False,
                "profile": {
                    "sex": "m",
                    "looking_for": "m",
                    "dob": "1995-01-01",
                },
                "hashed_token": self.hashed_token,
                "boost": False,
            }
        }

    def start_payload(self):
        user_data = self.user_payload()["user"]
        return {
            "user": user_data,
            "config": {
                "mode": "text",
                "settings": {
                    "device": None,
                    "interests": {"wait": 0, "tags": []},
                    "filters": {
                        "countries": [],
                        "regions": [],
                        "sex": [],
                        "max_wait": 3,
                    },
                    "profile": {
                        "sex": "m",
                        "looking_for": "m",
                        "dob": "1995-01-01",
                    },
                    "event": {"looking_for": "a"},
                    "privacy": {"hidden": False},
                },
            },
            "version": "20",
        }

    def send(self, topic, event, payload):
        if not self.ws:
            return
        msg = json.dumps([self.next_ref(), self.next_ref(), topic, event, payload])
        self.ws.send(msg, CurlWsFlag.TEXT)
        log.info(f"SEND [{topic}] {event}")

    def heartbeat(self):
        if self.ws:
            msg = json.dumps([None, self.next_ref(), "phoenix", "heartbeat", {}])
            self.ws.send(msg, CurlWsFlag.TEXT)

    def on_open(self, ws):
        self.ws = ws
        self.state = "searching"
        self.last_start_at = time.time()
        self.no_match_retries = 0
        log.info("Connected - joining match channel")
        self.send(self.match_topic, "phx_join", {
            "user": self.user_payload()["user"],
            "mode": "text",
        })
        time.sleep(1)
        self.send(self.match_topic, "rematch_restore", {})
        time.sleep(0.5)
        self._send_start()

    def on_message(self, ws, raw):
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            return
        if not isinstance(data, list) or len(data) < 4:
            return

        topic = data[2]
        event = data[3]
        payload = data[4] if len(data) > 4 else {}

        log.info(f"RECV [{topic}] {event}")

        if event == "phx_reply":
            self._handle_reply(payload)
            return

        if event == "matched":
            match_id = payload.get("match_id")
            partner = payload.get("partner", {})
            log.info(f"Matched with partner: {partner.get('id', 'unknown')}")
            self.state = "in_room"
            self.current_line_index = 0
            self.match_id = match_id
            self.room_topic = f"room:{match_id}"
            self.no_match_retries = 0
            self.send(self.room_topic, "phx_join", self.user_payload())

        elif event == "message":
            sender = payload.get("sender_id", "")
            if sender != self.user_id:
                body = payload.get("body", "")
                log.info(f"PARTNER: {body}")
                self._handle_partner_message()

        elif event == "disconnect":
            disc_match = payload.get("match_id", "")
            if disc_match and disc_match != self.match_id:
                return
            if self.state == "in_room" or disc_match == self.match_id:
                log.info("Partner disconnected")
                self._start_new_match()
            elif self.state == "searching" and disc_match:
                return

        elif event == "phx_close":
            if is_ban_payload(payload):
                log.warning(f"ACCOUNT BANNED (phx_close): {self.user_id}")
                self.is_banned = True
                self._close_ws()
                return
            self.state = "searching"
            self.room_topic = None
            self.match_id = None

        elif event == "error":
            if is_ban_payload(payload):
                log.warning(f"ACCOUNT BANNED (error event): {self.user_id}")
                self.is_banned = True
                self._close_ws()

    def _handle_reply(self, payload):
        """Inspect phx_reply payloads so server-side errors are no longer silent.

        Real shape: {"response": {...}, "status": "ok"} - status sits at the top
        level, while error detail (code/reason) lives inside response.
        """
        if not isinstance(payload, dict):
            return
        status = str(payload.get("status", "")).lower()
        resp = payload.get("response")
        resp = resp if isinstance(resp, dict) else {}
        code = str(resp.get("code", "")).lower()
        reason = str(resp.get("reason", "")).lower()
        if code == "captchafail" or "captcha" in reason:
            # Not expected in practice; just re-request a match instead of stalling.
            log.warning("Server replied captchafail - re-sending start")
            time.sleep(1.0)
            self._send_start()
        elif status == "error" or code or reason:
            log.warning(f"phx_reply error: status={status} code={code} reason={reason}")

    def on_close(self, ws, code, reason):
        log.info(f"Connection closed: {code} {reason}")
        if is_ban_close(code, reason):
            log.warning(f"ACCOUNT BANNED (close {code}): {self.user_id}")
            self.is_banned = True
        self.ws = None
        self.state = "stopped"

    def on_error(self, ws, exc):
        log.error(f"WS error: {exc}")

    def _close_ws(self):
        try:
            if self.ws:
                self.ws.close()
        except Exception:
            pass
        self.ws = None
        self.state = "stopped"

    def _handle_partner_message(self):
        if self.is_chat_exhausted() or not self.chat_lines:
            log.info("Chat file exhausted - starting new match")
            self._start_new_match()
            return
        line = replace_templates(
            self.get_next_line(), self.snaps, self.tg_users
        )
        time.sleep(self.response_time)
        if self.room_topic:
            self.send(self.room_topic, "message", {
                "body": line,
                "sender_id": self.user_id,
            })
            log.info(f"REPLIED: {line}")

    def _start_new_match(self):
        try:
            if self.room_topic:
                self.send(self.room_topic, "phx_leave", {})
        except Exception:
            pass
        if self.match_id:
            self.send(self.match_topic, "disconnect", {
                "to": "",
                "from": self.user_id,
                "match_id": self.match_id,
                "mode": "text",
                "videoLoaded": False,
            })
        self.state = "waiting"
        self.room_topic = None
        self.match_id = None
        self.current_line_index = 0
        self.reconnect_delay = self.wait_time
        self._close_ws()

    def _send_start(self):
        if not self.ws:
            return
        self.last_start_at = time.time()
        self.send(self.match_topic, "start", self.start_payload())

    def _heartbeat_loop(self):
        while not self._stop:
            time.sleep(30)
            if self._stop or not self.ws:
                continue
            try:
                self.heartbeat()
            except Exception:
                pass

    def _search_watcher(self):
        while not self._stop:
            try:
                if (
                    self.ws
                    and self.state == "searching"
                    and not self.stopped()
                    and not self.is_banned
                    and time.time() - self.last_start_at >= self.search_retry_time * 6
                ):
                    log.info(f"No match after {int(self.search_retry_time * 6)}s - reconnecting fresh")
                    if self.proxy_pool:
                        self.proxy = random.choice(self.proxy_pool)
                        host = self.proxy.split("@")[-1] if "@" in self.proxy else self.proxy
                        log.info(f"Switching proxy -> {host}")
                    self._close_ws()
            except Exception as e:
                log.error(f"Search watcher error: {e}")
            time.sleep(2)

    def stopped(self):
        return time.time() - self.started_at > self.thread_work_time

    def get_next_line(self):
        if self.current_line_index >= len(self.chat_lines):
            return None
        line = self.chat_lines[self.current_line_index]
        self.current_line_index += 1
        return line

    def is_chat_exhausted(self):
        return self.current_line_index >= len(self.chat_lines)

    def run(self):
        log.info(f"Running bot for user: {self.user_id}")
        watcher = threading.Thread(target=self._search_watcher, daemon=True)
        watcher.start()
        hb = threading.Thread(target=self._heartbeat_loop, daemon=True)
        hb.start()
        while not self._stop:
            try:
                log.info(f"Connecting ({self.user_id})...")
                ws = WebSocket(
                    on_open=self.on_open,
                    on_message=self.on_message,
                    on_close=self.on_close,
                    on_error=self.on_error,
                )
                kwargs = dict(
                    impersonate="chrome131",
                    timeout=30,
                    headers={"Origin": "https://thundr.com"},
                )
                if self.proxy:
                    kwargs["proxy"] = self.proxy
                ws.run_forever(self.build_url(), **kwargs)
            except WebSocketClosed:
                log.info("Socket closed, reconnecting...")
            except Exception as e:
                log.error(f"Run error: {e}")
                if self.proxy_pool:
                    self.proxy = random.choice(self.proxy_pool)
                    host = self.proxy.split("@")[-1] if "@" in self.proxy else self.proxy
                    log.info(f"Switching proxy -> {host}")

            if self._stop:
                break

            if self.is_banned:
                self.banned_user_ids.add(self.user_id)
                log.info(f"Account {self.user_id} banned - stopping bot")
                self._stop = True
                break

            if self.stopped():
                log.info(f"Work time reached for {self.user_id} - refreshing connection")
                self.started_at = time.time()
                self.reconnect_delay = 0
                continue

            delay = self.reconnect_delay if self.reconnect_delay else 5
            self.reconnect_delay = 0
            if delay > 5:
                log.info(f"Waiting {int(delay)}s before fresh reconnect...")
            time.sleep(delay)

        log.info(f"Bot finished for {self.user_id}")


def main():
    settings = load_settings()

    # Accounts arrive on the command line:
    #   chat.py acct:user_id|email|hashed_token [acct:... ...]
    # One process, one bot thread per account.
    acct_args = [a for a in sys.argv[1:] if a.startswith("acct:")]
    if acct_args:
        use_proxy_raw = settings.get("use_proxy", "").strip().lower()
        use_proxy = use_proxy_raw in ("1", "true", "yes", "y", "on")
        proxy_pool = load_proxies() if use_proxy else []
        threads = []
        for arg in acct_args:
            acc = parse_account_line(arg[5:])
            if acc is None:
                log.error(f"Invalid account format (skipped): {arg[:45]}...")
                continue
            proxy = random.choice(proxy_pool) if proxy_pool else None
            if proxy:
                host = proxy.split("@")[-1] if "@" in proxy else proxy
                log.info(f"Account {acc['user_id'][:8]}... -> proxy {host}")
            bot = ThundrBot(
                acc["user_id"], acc["email"], acc["hashed_token"], settings,
                proxy=proxy, proxy_pool=proxy_pool,
            )
            log.info(f"Starting bot for {acc['user_id']}")
            t = threading.Thread(target=bot.run, daemon=True)
            t.start()
            threads.append(t)
        if not threads:
            log.error("No valid accounts passed on the command line")
            return
        log.info(f"{len(threads)} bot(s) running (one thread per account)")
        try:
            while any(t.is_alive() for t in threads):
                time.sleep(1)
        except KeyboardInterrupt:
            log.info("Stopped by user")
        return

    log.error("No accounts passed.")
    log.error("Usage: python chat.py acct:user_id|email|hashed_token [acct:... ...]")
    log.error("Register accounts first: python register_browser.py --count 1 --start")


if __name__ == "__main__":
    main()
