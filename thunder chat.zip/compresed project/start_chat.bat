@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

if exist "C:\Users\aminee\Desktop\PythonProject\.venv\Scripts\python.exe" (
    set "PY=C:\Users\aminee\Desktop\PythonProject\.venv\Scripts\python.exe"
) else (
    set "PY=python"
)

rem accounts come from the command line, taken from registered_accounts.txt
set "ARGS="
for /f "usebackq delims=" %%A in ("registered_accounts.txt") do set "ARGS=!ARGS! acct:%%A"
if "!ARGS!"=="" (
    echo No accounts in registered_accounts.txt - run run.bat to register some.
    pause
    exit /b 1
)

echo Starting Chat Bot with the accounts from registered_accounts.txt ...
start "Thunder Chat Bot" "%PY%" chat.py !ARGS!
pause
