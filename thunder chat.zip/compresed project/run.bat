@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

rem --- pick python (project venv if present, else system) ---
if exist "C:\Users\aminee\Desktop\PythonProject\.venv\Scripts\python.exe" (
    set "PY=C:\Users\aminee\Desktop\PythonProject\.venv\Scripts\python.exe"
) else (
    set "PY=python"
)

echo ==============================================
echo   Thunder Chat Bot launcher
echo ==============================================
echo.
echo   [1] Register NEW account(s) in the browser, then chat
echo   [2] Chat with the accounts already in registered_accounts.txt
echo.
set /p MODE="Enter 1 or 2 [1]: "
if "%MODE%"=="" set MODE=1

if "%MODE%"=="2" goto EXISTING

rem ---------- register fresh accounts, then chat ----------
set /p COUNT="How many accounts to register? [1]: "
if "%COUNT%"=="" set COUNT=1
echo.
echo Registering %COUNT% account(s) (~30s each), then starting the bot ...
"%PY%" register_browser.py --count %COUNT% --start
goto DONE

rem ---------- reuse what is already registered ----------
:EXISTING
set "ARGS="
for /f "usebackq delims=" %%A in ("registered_accounts.txt") do set "ARGS=!ARGS! acct:%%A"
if "!ARGS!"=="" (
    echo.
    echo No accounts in registered_accounts.txt - pick [1] to register some.
    pause
    exit /b 1
)
echo.
echo Starting the bot with the accounts from registered_accounts.txt ...
start "Thunder Chat Bot" "%PY%" chat.py !ARGS!

:DONE
echo.
echo Done. Watch the "Thunder Chat" window, or tail chat.log:
echo     Get-Content chat.log -Tail 30
echo.
pause
